<div class="w3-padding-32">
    <div class="w3-bar w3-border">
        <a href="https://tyganeutronics.com" target="_blank" class="w3-bar-item w3-button">tyganeutronics.com</a>
        <a href="#projects" class="w3-bar-item w3-button w3-light-grey"><?= lang("Projects.site.portfolio") ?></a>
    </div>
</div>